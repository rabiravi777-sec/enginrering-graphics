"""
maze.py
-------
Procedural maze generation (recursive-backtracker + loop punching) and
the Maze class responsible for storage, collision queries, and
rendering.

Rendering deliberately avoids pygame.draw.rect/circle for the required
elements:
    - walls          -> bresenham_line (Algorithm 2)
    - pellets/power  -> midpoint_circle (Algorithm 3)
    - floor texture  -> flood_fill      (Algorithm 5)
"""

import random
import pygame

import constants as C
import graphics_algorithms as ga


WALL = "#"
FLOOR = "."
EMPTY = " "


def _generate_cell_maze(cells_w, cells_h, loop_prob, seed):
    """
    Builds a maze on a grid of (cells_w x cells_h) logical cells using a
    randomized depth-first-search ("recursive backtracker"). This
    guarantees a perfect maze (every cell reachable, no isolated areas).

    The logical cell maze is then expanded into a TILE grid of size
    (2*cells_w+1) x (2*cells_h+1): cells sit on odd tile coordinates and
    the tile between two adjacent cells represents the wall/passage
    between them.

    After the perfect maze is built, a fraction of the still-standing
    inner walls (loop_prob) are knocked down to introduce loops so the
    maze doesn't feel like a single dead-end-riddled corridor - this is
    exactly the knob levels.py uses to make Level 1 "open" and Level 3
    "maze-like".
    """
    rng = random.Random(seed)

    tiles_w = cells_w * 2 + 1
    tiles_h = cells_h * 2 + 1
    grid = [[WALL for _ in range(tiles_w)] for _ in range(tiles_h)]

    visited = [[False] * cells_w for _ in range(cells_h)]

    def cell_to_tile(cx, cy):
        return cx * 2 + 1, cy * 2 + 1

    def carve(cx, cy):
        visited[cy][cx] = True
        tx, ty = cell_to_tile(cx, cy)
        grid[ty][tx] = FLOOR

        neighbors = [(0, -1), (0, 1), (-1, 0), (1, 0)]
        rng.shuffle(neighbors)
        for dx, dy in neighbors:
            nx, ny = cx + dx, cy + dy
            if 0 <= nx < cells_w and 0 <= ny < cells_h and not visited[ny][nx]:
                # knock down the wall between (cx,cy) and (nx,ny)
                wall_x = tx + dx
                wall_y = ty + dy
                grid[wall_y][wall_x] = FLOOR
                carve(nx, ny)

    carve(rng.randrange(cells_w), rng.randrange(cells_h))

    # ---- punch extra loops --------------------------------------------
    # Any WALL tile that sits directly between two FLOOR cell-tiles is a
    # candidate for removal (this creates a loop instead of a strict tree).
    for ty in range(1, tiles_h - 1):
        for tx in range(1, tiles_w - 1):
            if grid[ty][tx] != WALL:
                continue
            # horizontal neighbor pair
            if tx % 2 == 0 and ty % 2 == 1:
                if grid[ty][tx - 1] == FLOOR and grid[ty][tx + 1] == FLOOR:
                    if rng.random() < loop_prob:
                        grid[ty][tx] = FLOOR
            # vertical neighbor pair
            elif tx % 2 == 1 and ty % 2 == 0:
                if grid[ty - 1][tx] == FLOOR and grid[ty + 1][tx] == FLOOR:
                    if rng.random() < loop_prob:
                        grid[ty][tx] = FLOOR

    return grid, tiles_w, tiles_h


class Maze:
    def __init__(self, level_number):
        cfg = C.LEVEL_CONFIG[level_number]
        self.level_number = level_number
        self.cfg = cfg

        grid, tiles_w, tiles_h = _generate_cell_maze(
            cfg["cells_w"], cfg["cells_h"], cfg["loop_prob"], cfg["seed"]
        )
        self.grid = grid
        self.cols = tiles_w
        self.rows = tiles_h

        # Center the maze inside the play area.
        play_h = C.SCREEN_HEIGHT - C.HUD_HEIGHT
        self.offset_x = (C.SCREEN_WIDTH - self.cols * C.TILE_SIZE) // 2
        self.offset_y = C.HUD_HEIGHT + (play_h - self.rows * C.TILE_SIZE) // 2

        self.pellets = set()       # set of (col,row) with a normal pellet
        self.power_pellets = set()  # set of (col,row) with a power pellet

        self._place_spawns_and_pellets()
        self._floor_surface = self._build_floor_texture()
        self._wall_surface = self._build_wall_surface()

        self.total_pellets = len(self.pellets) + len(self.power_pellets)

    # ------------------------------------------------------------------
    # SETUP
    # ------------------------------------------------------------------
    def _floor_tiles(self):
        for y in range(self.rows):
            for x in range(self.cols):
                if self.grid[y][x] == FLOOR:
                    yield (x, y)

    def _place_spawns_and_pellets(self):
        floor_tiles = list(self._floor_tiles())

        # Player spawn: bottom-most, then left-most floor tile.
        floor_tiles.sort(key=lambda t: (-t[1], t[0]))
        self.player_spawn = floor_tiles[0]

        # Ghost home: the tile closest to the geometric center of the maze.
        cx, cy = self.cols / 2.0, self.rows / 2.0
        center_sorted = sorted(
            floor_tiles, key=lambda t: (t[0] - cx) ** 2 + (t[1] - cy) ** 2
        )
        home = center_sorted[0]
        # Try to pick 4 distinct nearby tiles for the 4 ghosts.
        self.ghost_spawns = center_sorted[:4]
        while len(self.ghost_spawns) < 4:
            self.ghost_spawns.append(home)

        reserved = set(self.ghost_spawns) | {self.player_spawn}

        # Power pellets: the 4 tiles farthest from the player spawn,
        # spread across the maze corners.
        far_sorted = sorted(
            floor_tiles,
            key=lambda t: -((t[0] - self.player_spawn[0]) ** 2 + (t[1] - self.player_spawn[1]) ** 2),
        )
        power_tiles = []
        for t in far_sorted:
            if t in reserved:
                continue
            if all((abs(t[0] - p[0]) + abs(t[1] - p[1])) > 3 for p in power_tiles):
                power_tiles.append(t)
            if len(power_tiles) == 4:
                break
        self.power_pellets = set(power_tiles)
        reserved |= self.power_pellets

        # Every remaining floor tile gets a normal pellet.
        self.pellets = {t for t in floor_tiles if t not in reserved}

    def _build_floor_texture(self):
        """
        ALGORITHM 5 - FLOOD FILL
        Build a tiny 1-pixel-per-tile surface, mark every tile as an
        "unknown" placeholder color, then flood-fill outward from the
        player's spawn tile to discover every reachable floor tile and
        recolor it. This is then scaled up to become the floor tint
        layer drawn behind the maze.
        """
        tiny = pygame.Surface((self.cols, self.rows))
        UNVISITED_FLOOR = (1, 1, 1)
        WALL_MARK = (2, 2, 2)

        for y in range(self.rows):
            for x in range(self.cols):
                if self.grid[y][x] == FLOOR:
                    tiny.set_at((x, y), UNVISITED_FLOOR)
                else:
                    tiny.set_at((x, y), WALL_MARK)

        px, py = self.player_spawn
        ga.flood_fill(tiny, px, py, UNVISITED_FLOOR, C.FLOOR_TINT)

        # Any floor tile the flood fill could not reach (would indicate
        # a disconnected maze) is marked in a warning color so it is
        # obvious during development; with the recursive-backtracker
        # generator above this should never happen.
        for y in range(self.rows):
            for x in range(self.cols):
                if tuple(tiny.get_at((x, y)))[:3] == UNVISITED_FLOOR:
                    tiny.set_at((x, y), (80, 0, 0))

        scaled = pygame.transform.scale(
            tiny, (self.cols * C.TILE_SIZE, self.rows * C.TILE_SIZE)
        )
        return scaled

    def _build_wall_surface(self):
        """
        ALGORITHM 2 - BRESENHAM'S LINE
        Pre-render the maze walls once onto a cached surface using
        Bresenham lines connecting the centers of adjacent wall tiles
        (thickened to a full tile width), instead of pygame.draw.rect.
        """
        surface = pygame.Surface(
            (self.cols * C.TILE_SIZE, self.rows * C.TILE_SIZE), pygame.SRCALPHA
        )

        def tile_center(tx, ty):
            return (tx * C.TILE_SIZE + C.TILE_SIZE // 2,
                    ty * C.TILE_SIZE + C.TILE_SIZE // 2)

        thickness = C.TILE_SIZE
        drawn_isolated = set()

        for y in range(self.rows):
            for x in range(self.cols):
                if self.grid[y][x] != WALL:
                    continue
                cxy = tile_center(x, y)
                has_neighbor = False

                # connect to the wall neighbor on the right
                if x + 1 < self.cols and self.grid[y][x + 1] == WALL:
                    nxy = tile_center(x + 1, y)
                    ga.bresenham_line(surface, cxy[0], cxy[1], nxy[0], nxy[1],
                                       C.WALL_COLOR, thickness)
                    has_neighbor = True

                # connect to the wall neighbor below
                if y + 1 < self.rows and self.grid[y + 1][x] == WALL:
                    nxy = tile_center(x, y + 1)
                    ga.bresenham_line(surface, cxy[0], cxy[1], nxy[0], nxy[1],
                                       C.WALL_COLOR, thickness)
                    has_neighbor = True

                if not has_neighbor:
                    # isolated wall tile (rare) - still draw a full tile
                    # sized dot so no gaps appear in the maze border.
                    ga.bresenham_line(surface, cxy[0], cxy[1], cxy[0], cxy[1],
                                       C.WALL_COLOR, thickness)
                    drawn_isolated.add((x, y))

        return surface

    # ------------------------------------------------------------------
    # QUERIES
    # ------------------------------------------------------------------
    def is_wall(self, col, row):
        if 0 <= row < self.rows and 0 <= col < self.cols:
            return self.grid[row][col] == WALL
        return True

    def tile_to_pixel_center(self, col, row):
        return (
            self.offset_x + col * C.TILE_SIZE + C.TILE_SIZE // 2,
            self.offset_y + row * C.TILE_SIZE + C.TILE_SIZE // 2,
        )

    def pixel_to_tile(self, px, py):
        col = (px - self.offset_x) // C.TILE_SIZE
        row = (py - self.offset_y) // C.TILE_SIZE
        return int(col), int(row)

    def valid_neighbors(self, col, row):
        """Return list of (dx,dy) directions leading to a non-wall tile."""
        options = []
        for d in (C.UP, C.DOWN, C.LEFT, C.RIGHT):
            nc, nr = col + d[0], row + d[1]
            if not self.is_wall(nc, nr):
                options.append(d)
        return options

    # ------------------------------------------------------------------
    # PELLET LOGIC
    # ------------------------------------------------------------------
    def try_collect(self, col, row):
        """Returns 'pellet', 'power', or None, removing the item if found."""
        if (col, row) in self.pellets:
            self.pellets.discard((col, row))
            return "pellet"
        if (col, row) in self.power_pellets:
            self.power_pellets.discard((col, row))
            return "power"
        return None

    def remaining_pellets(self):
        return len(self.pellets) + len(self.power_pellets)

    # ------------------------------------------------------------------
    # RENDERING
    # ------------------------------------------------------------------
    def draw(self, surface):
        surface.blit(self._floor_surface, (self.offset_x, self.offset_y))
        surface.blit(self._wall_surface, (self.offset_x, self.offset_y))

        # ---- ALGORITHM 3: MIDPOINT CIRCLE (pellets & power pellets) ----
        for (col, row) in self.pellets:
            cx, cy = self.tile_to_pixel_center(col, row)
            ga.midpoint_circle(surface, cx, cy, max(2, C.TILE_SIZE // 10), C.PELLET_COLOR)

        pulse = 2 if (pygame.time.get_ticks() // 250) % 2 == 0 else 0
        for (col, row) in self.power_pellets:
            cx, cy = self.tile_to_pixel_center(col, row)
            ga.midpoint_circle(surface, cx, cy, C.TILE_SIZE // 4 + pulse, C.POWER_COLOR)
