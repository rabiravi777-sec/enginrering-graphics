"""
player.py
---------
The player-controlled Pac-Man style character.

Movement: grid-aligned. The player travels in a straight line between
tile centers; a buffered "desired direction" is applied the instant the
player is aligned with a tile center and that direction is open, which
gives responsive classic Pac-Man controls without ever clipping walls.

Drawing: the body + animated mouth wedge is generated as a polygon
(Algorithm 7 - Scan-line Polygon Fill) rather than pygame.draw.circle.
"""

import math
import pygame

import constants as C
import graphics_algorithms as ga


class Player:
    def __init__(self, maze):
        self.maze = maze
        col, row = maze.player_spawn
        self.x, self.y = maze.tile_to_pixel_center(col, row)
        self.direction = C.NONE_DIR
        self.desired_dir = C.NONE_DIR
        self.speed = C.PLAYER_BASE_SPEED * C.TILE_SIZE
        self.mouth_phase = 0.0
        self.facing_angle = 180  # degrees, 0 = right, 90 = up (screen coords)
        self.radius = C.TILE_SIZE // 2 - 2
        self._last_decision_tile = None

    def set_desired_direction(self, direction):
        self.desired_dir = direction

    def current_tile(self):
        return self.maze.pixel_to_tile(self.x, self.y)

    def reset_to_spawn(self):
        col, row = self.maze.player_spawn
        self.x, self.y = self.maze.tile_to_pixel_center(col, row)
        self.direction = C.NONE_DIR
        self.desired_dir = C.NONE_DIR
        self._last_decision_tile = None

    # ------------------------------------------------------------------
    def update(self, dt):
        maze = self.maze
        move_dist = self.speed * dt

        # Allow an instant 180-degree reversal at any time (classic feel).
        if self.direction != C.NONE_DIR and self.desired_dir == (
            -self.direction[0], -self.direction[1]
        ):
            self.direction = self.desired_dir
            self._last_decision_tile = None  # allow re-deciding immediately

        col, row = maze.pixel_to_tile(self.x, self.y)
        tcx, tcy = maze.tile_to_pixel_center(col, row)
        snap_radius = move_dist + 0.5
        near_center = abs(self.x - tcx) <= snap_radius and abs(self.y - tcy) <= snap_radius

        # Only re-evaluate direction the FIRST time we arrive near a given
        # tile's center - this prevents the character from perpetually
        # snapping back to the same center and never crossing into the
        # next tile.
        if near_center and self._last_decision_tile != (col, row):
            self._last_decision_tile = (col, row)
            self.x, self.y = tcx, tcy
            if self.desired_dir != C.NONE_DIR and not maze.is_wall(
                col + self.desired_dir[0], row + self.desired_dir[1]
            ):
                self.direction = self.desired_dir
            if self.direction != C.NONE_DIR and maze.is_wall(
                col + self.direction[0], row + self.direction[1]
            ):
                self.direction = C.NONE_DIR

        # While stopped, keep checking every frame so a newly buffered
        # direction is applied the instant it becomes valid.
        if self.direction == C.NONE_DIR:
            self._last_decision_tile = None

        if self.direction != C.NONE_DIR:
            self.x += self.direction[0] * move_dist
            self.y += self.direction[1] * move_dist
            angle_map = {C.RIGHT: 0, C.UP: 90, C.LEFT: 180, C.DOWN: 270}
            self.facing_angle = angle_map[self.direction]
            self.mouth_phase += dt * 10.0
        else:
            self.mouth_phase += dt * 4.0

        # Try to collect whatever is on the tile we are centered on.
        col, row = maze.pixel_to_tile(self.x, self.y)
        return maze.try_collect(col, row)

    def rect(self):
        r = self.radius
        return pygame.Rect(self.x - r, self.y - r, r * 2, r * 2)

    # ------------------------------------------------------------------
    def draw(self, surface):
        """
        ALGORITHM 7 - SCAN-LINE POLYGON FILL
        Pac-Man's body is generated as a polygon: an arc of points
        around the circle (skipping a wedge around the facing angle to
        form the mouth) plus the center point, filled with the
        scan-line algorithm.
        """
        mouth_half_angle = abs(math.sin(self.mouth_phase)) * 40  # degrees, 0..40

        points = [(self.x, self.y)]
        start = self.facing_angle + mouth_half_angle
        end = self.facing_angle + 360 - mouth_half_angle
        segments = 24
        for i in range(segments + 1):
            a = math.radians(start + (end - start) * i / segments)
            px = self.x + self.radius * math.cos(a)
            # screen y grows downward, so subtract sin to match facing_angle map
            py = self.y - self.radius * math.sin(a)
            points.append((px, py))

        ga.scanline_polygon_fill(surface, points, C.YELLOW)

        # simple eye (also drawn with the midpoint circle algorithm)
        eye_y = self.y - self.radius * 0.4
        ga.midpoint_circle(surface, self.x, eye_y, 2, C.BLACK)
