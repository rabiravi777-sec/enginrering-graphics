"""
menu.py
-------
Rendering helpers for every non-gameplay screen: main menu, level
select, pause, game over, level complete, and victory.

A small decorative touch (the divider line under the title) is drawn
with the Bresenham algorithm again, just to keep menu rendering in the
spirit of "manually drawn graphics" rather than relying purely on
pygame's font/rect helpers.
"""

import pygame

import constants as C
import graphics_algorithms as ga


def _draw_title(surface, font_big, text, y):
    label = font_big.render(text, True, C.MENU_HILIGHT)
    rect = label.get_rect(center=(C.SCREEN_WIDTH // 2, y))
    surface.blit(label, rect)
    ga.bresenham_line(
        surface, rect.left, rect.bottom + 8, rect.right, rect.bottom + 8,
        C.MENU_HILIGHT, thickness=2,
    )


def _draw_options(surface, font, options, selected_index, start_y, gap=48, sub_font=None, subtitles=None):
    for i, text in enumerate(options):
        color = C.MENU_HILIGHT if i == selected_index else C.TEXT_COLOR
        label = font.render(text, True, color)
        rect = label.get_rect(center=(C.SCREEN_WIDTH // 2, start_y + i * gap))
        if i == selected_index:
            prefix = font.render(">", True, C.MENU_HILIGHT)
            surface.blit(prefix, (rect.left - 34, rect.top))
        surface.blit(label, rect)
        if subtitles and subtitles[i]:
            sub_label = sub_font.render(subtitles[i], True, (170, 170, 180))
            sub_rect = sub_label.get_rect(center=(C.SCREEN_WIDTH // 2, start_y + i * gap + 22))
            surface.blit(sub_label, sub_rect)


def draw_main_menu(surface, fonts, selected_index):
    surface.fill(C.DARK_BLUE)
    _draw_title(surface, fonts["huge"], "MAZE CHASE", 160)
    options = ["START GAME", "LEVELS", "QUIT"]
    _draw_options(surface, fonts["large"], options, selected_index, 340, gap=60)

    hint = fonts["small"].render("Arrow keys / WASD to move, Enter to select", True, (150, 150, 160))
    surface.blit(hint, hint.get_rect(center=(C.SCREEN_WIDTH // 2, C.SCREEN_HEIGHT - 60)))


def draw_level_select(surface, fonts, selected_index, unlocked_levels):
    import levels as L

    surface.fill(C.DARK_BLUE)
    _draw_title(surface, fonts["large"], "SELECT LEVEL", 110)

    options = []
    subtitles = []
    for lvl in L.LEVEL_ORDER:
        cfg = L.get_level_config(lvl)
        locked = lvl not in unlocked_levels
        label = f'{cfg["name"]}' + ("  (LOCKED)" if locked else "")
        options.append(label)
        subtitles.append(cfg["difficulty"])
    options.append("BACK")
    subtitles.append(None)

    _draw_options(surface, fonts["medium"], options, selected_index, 240, gap=70,
                  sub_font=fonts["small"], subtitles=subtitles)

    hint = fonts["small"].render("Enter to select, Escape to go back", True, (150, 150, 160))
    surface.blit(hint, hint.get_rect(center=(C.SCREEN_WIDTH // 2, C.SCREEN_HEIGHT - 60)))


def draw_pause(surface, fonts, selected_index):
    overlay = pygame.Surface((C.SCREEN_WIDTH, C.SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    surface.blit(overlay, (0, 0))

    _draw_title(surface, fonts["large"], "PAUSED", 220)
    options = ["RESUME", "MAIN MENU"]
    _draw_options(surface, fonts["medium"], options, selected_index, 360, gap=56)


def draw_game_over(surface, fonts, selected_index, score):
    surface.fill(C.BLACK)
    _draw_title(surface, fonts["huge"], "GAME OVER", 180)

    score_label = fonts["medium"].render(f"SCORE: {score}", True, C.TEXT_COLOR)
    surface.blit(score_label, score_label.get_rect(center=(C.SCREEN_WIDTH // 2, 280)))

    options = ["RESTART", "MAIN MENU", "QUIT"]
    _draw_options(surface, fonts["medium"], options, selected_index, 400, gap=56)


def draw_level_complete(surface, fonts, score, level_number):
    surface.fill(C.DARK_BLUE)
    _draw_title(surface, fonts["huge"], "LEVEL COMPLETE!", 220)

    score_label = fonts["medium"].render(f"SCORE: {score}", True, C.TEXT_COLOR)
    surface.blit(score_label, score_label.get_rect(center=(C.SCREEN_WIDTH // 2, 320)))

    hint = fonts["small"].render("Press ENTER to continue", True, (170, 170, 180))
    surface.blit(hint, hint.get_rect(center=(C.SCREEN_WIDTH // 2, 420)))


def draw_victory(surface, fonts, selected_index, score):
    surface.fill(C.DARK_BLUE)
    _draw_title(surface, fonts["huge"], "YOU WIN!", 180)

    score_label = fonts["medium"].render(f"FINAL SCORE: {score}", True, C.TEXT_COLOR)
    surface.blit(score_label, score_label.get_rect(center=(C.SCREEN_WIDTH // 2, 280)))

    options = ["PLAY AGAIN", "MAIN MENU", "QUIT"]
    _draw_options(surface, fonts["medium"], options, selected_index, 400, gap=56)
