"""
ghost.py
--------
The four ghost enemies. Each has a distinct, simple AI:

    CHASER   - always steers toward Pac-Man's current tile.
    AMBUSHER - steers toward a point a few tiles ahead of Pac-Man,
               trying to cut him off rather than tailing him.
    RANDOM   - wanders, picking a random open direction at every
               intersection.
    PATROL   - alternates between chasing and wandering every few
               seconds, so it feels unpredictable.

Drawing uses:
    - scanline_polygon_fill (Algorithm 7) for the ghost body
    - midpoint_ellipse      (Algorithm 4) for the eyes
    - midpoint_circle       (Algorithm 3) for a pulsing "vulnerability"
      ring while scared
    - dda_line + cohen_sutherland_clip (Algorithms 1 & 6) for the
      optional "vision ray" drawn from a chasing ghost toward Pac-Man
"""

import math
import random

import pygame

import constants as C
import graphics_algorithms as ga

CHASER = "chaser"
AMBUSHER = "ambusher"
RANDOM_GHOST = "random"
PATROL = "patrol"

STATE_NORMAL = "normal"
STATE_SCARED = "scared"
STATE_EATEN = "eaten"

GHOST_DEFS = [
    (CHASER, C.RED),
    (AMBUSHER, C.PINK),
    (RANDOM_GHOST, C.CYAN),
    (PATROL, C.ORANGE),
]

PATROL_SWITCH_INTERVAL = 4.0


class Ghost:
    def __init__(self, maze, behavior, color, home_tile, speed_multiplier, rng_seed):
        self.maze = maze
        self.behavior = behavior
        self.base_color = color
        self.home_tile = home_tile
        self.speed_multiplier = speed_multiplier
        self.rng = random.Random(rng_seed)

        col, row = home_tile
        self.x, self.y = maze.tile_to_pixel_center(col, row)
        self.direction = self._pick_initial_direction(col, row)
        self.state = STATE_NORMAL
        self.patrol_timer = 0.0
        self.patrol_chasing = True
        self.radius = C.TILE_SIZE // 2 - 2
        self._last_decision_tile = None

    def _pick_initial_direction(self, col, row):
        options = self.maze.valid_neighbors(col, row)
        return self.rng.choice(options) if options else C.NONE_DIR

    def reset_to_home(self):
        col, row = self.home_tile
        self.x, self.y = self.maze.tile_to_pixel_center(col, row)
        self.direction = self._pick_initial_direction(col, row)
        self.state = STATE_NORMAL
        self._last_decision_tile = None

    def set_scared(self):
        if self.state != STATE_EATEN:
            self.state = STATE_SCARED

    def clear_scared(self):
        if self.state == STATE_SCARED:
            self.state = STATE_NORMAL

    def get_eaten(self):
        self.state = STATE_EATEN

    # ------------------------------------------------------------------
    def _current_speed(self):
        base = C.GHOST_BASE_SPEED * C.TILE_SIZE * self.speed_multiplier
        if self.state == STATE_SCARED:
            return base * C.SCARED_SPEED_MULT
        if self.state == STATE_EATEN:
            return base * 1.6
        return base

    def _target_tile(self, player, patrol_state_holder):
        p_col, p_row = player.current_tile()

        if self.state == STATE_EATEN:
            return self.home_tile

        if self.behavior == CHASER:
            return (p_col, p_row)

        if self.behavior == AMBUSHER:
            dx, dy = player.direction if player.direction != C.NONE_DIR else C.LEFT
            return (p_col + dx * 4, p_row + dy * 4)

        if self.behavior == RANDOM_GHOST:
            return None  # signals "no target, pick randomly"

        if self.behavior == PATROL:
            self.patrol_timer += patrol_state_holder["dt"]
            if self.patrol_timer >= PATROL_SWITCH_INTERVAL:
                self.patrol_timer = 0.0
                self.patrol_chasing = not self.patrol_chasing
            if self.patrol_chasing:
                return (p_col, p_row)
            return None

        return (p_col, p_row)

    def _choose_direction(self, col, row, target, flee):
        options = self.maze.valid_neighbors(col, row)
        if not options:
            return C.NONE_DIR

        reverse = (-self.direction[0], -self.direction[1])
        non_reverse = [d for d in options if d != reverse]
        candidates = non_reverse if non_reverse else options

        if target is None:
            return self.rng.choice(candidates)

        def score(d):
            nx, ny = col + d[0], row + d[1]
            dist = (nx - target[0]) ** 2 + (ny - target[1]) ** 2
            return -dist if flee else dist

        return min(candidates, key=score)

    # ------------------------------------------------------------------
    def update(self, dt, player, patrol_dt_holder):
        maze = self.maze
        speed = self._current_speed()
        move_dist = speed * dt

        col, row = maze.pixel_to_tile(self.x, self.y)
        tcx, tcy = maze.tile_to_pixel_center(col, row)
        snap_radius = move_dist + 0.5
        near_center = abs(self.x - tcx) <= snap_radius and abs(self.y - tcy) <= snap_radius

        if self.state == STATE_EATEN and (col, row) == self.home_tile and near_center:
            self.state = STATE_NORMAL

        # Only re-decide direction the first time we arrive near a given
        # tile's center, so the ghost doesn't perpetually snap back to
        # the same center and stall.
        if near_center and self._last_decision_tile != (col, row):
            self._last_decision_tile = (col, row)
            self.x, self.y = tcx, tcy
            target = self._target_tile(player, patrol_dt_holder)
            flee = self.state == STATE_SCARED
            new_dir = self._choose_direction(col, row, target, flee)
            if new_dir != C.NONE_DIR:
                self.direction = new_dir
            else:
                self._last_decision_tile = None

        if self.direction != C.NONE_DIR:
            self.x += self.direction[0] * move_dist
            self.y += self.direction[1] * move_dist

    def rect_center(self):
        return self.x, self.y

    # ------------------------------------------------------------------
    def draw(self, surface, scared_time_left=0.0):
        if self.state == STATE_EATEN:
            self._draw_eyes(surface, C.WHITE)
            return

        if self.state == STATE_SCARED:
            flashing = scared_time_left < 2.0 and int(scared_time_left * 5) % 2 == 0
            color = C.GHOST_SCARED_FLASH if flashing else C.GHOST_SCARED
        else:
            color = self.base_color

        # -------------------------------------------------------------
        # ALGORITHM 7 - SCAN-LINE POLYGON FILL: ghost body
        # dome top + wavy "skirt" bottom, built as a single polygon.
        # -------------------------------------------------------------
        r = self.radius
        top = self.y - r
        bottom = self.y + r * 0.9
        points = []
        dome_segments = 12
        for i in range(dome_segments + 1):
            a = math.pi + (math.pi * i / dome_segments)  # left side to right side over the top
            px = self.x + r * math.cos(a)
            py = self.y + r * math.sin(a)
            points.append((px, py))
        # right side down to skirt
        points.append((self.x + r, bottom))
        # wavy skirt from right to left
        waves = 4
        for i in range(waves * 2 + 1):
            t = i / (waves * 2)
            px = self.x + r - t * (2 * r)
            py = bottom if i % 2 == 0 else bottom - r * 0.35
            points.append((px, py))
        points.append((self.x - r, bottom))

        ga.scanline_polygon_fill(surface, points, color)

        # -------------------------------------------------------------
        # ALGORITHM 3 - MIDPOINT CIRCLE: pulsing vulnerability ring
        # -------------------------------------------------------------
        if self.state == STATE_SCARED:
            pulse_r = r + 3 + int(2 * abs(math.sin(pygame.time.get_ticks() / 150.0)))
            ga.midpoint_circle(surface, self.x, self.y, pulse_r, C.WHITE, filled=False)

        eye_color = C.WHITE
        self._draw_eyes(surface, eye_color)

    def _draw_eyes(self, surface, color):
        """ALGORITHM 4 - MIDPOINT ELLIPSE: ghost eyes (sclera + pupil)."""
        r = self.radius
        ex_off = r * 0.35
        ey_off = -r * 0.1
        for side in (-1, 1):
            ex = self.x + side * ex_off
            ey = self.y + ey_off
            ga.midpoint_ellipse(surface, ex, ey, r * 0.22, r * 0.28, color)
            # pupil looks toward current direction of travel
            pdx, pdy = self.direction if self.direction != C.NONE_DIR else (0, 0)
            pupil_x = ex + pdx * r * 0.08
            pupil_y = ey - pdy * r * 0.08
            ga.midpoint_ellipse(surface, pupil_x, pupil_y, r * 0.1, r * 0.12, C.BLACK)

    def draw_vision_ray(self, surface, player, viewport_rect):
        """
        ALGORITHM 1 - DDA LINE + ALGORITHM 6 - COHEN-SUTHERLAND CLIP
        A thin ray from a normally-chasing ghost toward Pac-Man,
        clipped to the play-area viewport before it is drawn.
        """
        if self.state != STATE_NORMAL or self.behavior not in (CHASER, PATROL):
            return

        clipped = ga.cohen_sutherland_clip(
            self.x, self.y, player.x, player.y,
            viewport_rect.left, viewport_rect.top,
            viewport_rect.right, viewport_rect.bottom,
        )
        if clipped is None:
            return
        cx1, cy1, cx2, cy2 = clipped
        faint = tuple(min(255, c + 40) for c in self.base_color)
        ga.dda_line(surface, cx1, cy1, cx2, cy2, faint, thickness=1)
