"""
constants.py
------------
All tunable numbers and shared configuration live here so nothing is
scattered through the rest of the codebase.
"""

# --------------------------------------------------------------------------
# WINDOW / GRID
# --------------------------------------------------------------------------
TILE_SIZE = 30
HUD_HEIGHT = 70
SCREEN_WIDTH = 700
SCREEN_HEIGHT = 700 + HUD_HEIGHT
FPS = 60

# --------------------------------------------------------------------------
# COLORS
# --------------------------------------------------------------------------
BLACK = (8, 8, 12)
DARK_BLUE = (10, 12, 40)
WALL_COLOR = (33, 90, 220)
WALL_GLOW = (90, 150, 255)
FLOOR_TINT = (18, 18, 30)
WHITE = (240, 240, 240)
YELLOW = (255, 221, 0)
PELLET_COLOR = (255, 224, 145)
POWER_COLOR = (255, 140, 60)
RED = (220, 40, 40)
PINK = (255, 120, 180)
CYAN = (80, 220, 220)
ORANGE = (255, 160, 40)
GHOST_SCARED = (60, 70, 220)
GHOST_SCARED_FLASH = (230, 230, 230)
TEXT_COLOR = (245, 245, 245)
MENU_HILIGHT = (255, 221, 0)
GREEN = (80, 220, 120)

# --------------------------------------------------------------------------
# GAME STATES
# --------------------------------------------------------------------------
STATE_MAIN_MENU = "MAIN_MENU"
STATE_LEVEL_SELECT = "LEVEL_SELECT"
STATE_PLAYING = "PLAYING"
STATE_PAUSED = "PAUSED"
STATE_LEVEL_COMPLETE = "LEVEL_COMPLETE"
STATE_GAME_OVER = "GAME_OVER"
STATE_VICTORY = "VICTORY"

# --------------------------------------------------------------------------
# GAMEPLAY
# --------------------------------------------------------------------------
STARTING_LIVES = 3
PELLET_SCORE = 10
POWER_PELLET_SCORE = 50
GHOST_EAT_SCORE = 200
POWER_DURATION = 7.0          # seconds of power mode
PLAYER_BASE_SPEED = 3.6       # tiles per second
GHOST_BASE_SPEED = 3.0        # tiles per second (multiplied by level ghost_speed)
SCARED_SPEED_MULT = 0.6

# Directions as (dx, dy) in grid units
UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)
NONE_DIR = (0, 0)

# --------------------------------------------------------------------------
# LEVEL CONFIGURATION
# Only numbers change here to retune difficulty - nothing else in the
# codebase needs to change to add/adjust a level.
# --------------------------------------------------------------------------
LEVEL_CONFIG = {
    1: {
        "name": "LEVEL 1",
        "difficulty": "Easy",
        "cells_w": 8,
        "cells_h": 7,
        "loop_prob": 0.35,      # higher = more open corridors / loops
        "ghost_speed": 1.0,
        "seed": 101,
    },
    2: {
        "name": "LEVEL 2",
        "difficulty": "Medium",
        "cells_w": 9,
        "cells_h": 9,
        "loop_prob": 0.18,
        "ghost_speed": 1.3,
        "seed": 202,
    },
    3: {
        "name": "LEVEL 3",
        "difficulty": "Hard",
        "cells_w": 10,
        "cells_h": 10,
        "loop_prob": 0.06,      # low = long corridors, more dead ends
        "ghost_speed": 1.6,
        "seed": 303,
    },
}
