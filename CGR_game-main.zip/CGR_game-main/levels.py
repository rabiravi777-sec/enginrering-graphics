"""
levels.py
---------
Thin convenience wrapper around constants.LEVEL_CONFIG so the rest of
the code can ask "what levels exist / what's next" without reaching
into constants directly everywhere.
"""

import constants as C

LEVEL_ORDER = [1, 2, 3]


def get_level_config(level_number):
    return C.LEVEL_CONFIG[level_number]


def next_level(level_number):
    idx = LEVEL_ORDER.index(level_number)
    if idx + 1 < len(LEVEL_ORDER):
        return LEVEL_ORDER[idx + 1]
    return None


def level_display_name(level_number):
    cfg = get_level_config(level_number)
    return f'{cfg["name"]} - {cfg["difficulty"]}'
