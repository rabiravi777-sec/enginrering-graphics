# MAZE CHASE

A Pac-Man-style arcade maze game built in **Python + Pygame**, created as a
Computer Graphics academic project. All graphics are generated
programmatically — there are no external image assets — and **seven
Computer Graphics algorithms are implemented manually from scratch** and
used throughout the game's rendering pipeline.

---

## 1. Installation

```bash
pip install pygame
```

(Tested with `pygame==2.6.1` / Python 3.12, but any recent Python 3 + Pygame
2.x should work.)

## 2. How to Run

```bash
python main.py
```

## 3. Controls

| Key | Action |
|---|---|
| `W` / `Up Arrow` | Move up |
| `S` / `Down Arrow` | Move down |
| `A` / `Left Arrow` | Move left |
| `D` / `Right Arrow` | Move right |
| `Enter` / `Space` | Select menu option / continue |
| `P` | Pause / resume |
| `Esc` | Back to main menu (during gameplay) / back a menu (level select) |

## 4. Project Structure

```
pacman_project/
│
├── main.py                  # Entry point
├── game.py                  # Game class: state machine, update/draw, HUD
├── player.py                # Player (Pac-Man) class
├── ghost.py                 # Ghost class + 4 AI behaviors
├── maze.py                  # Procedural maze generation + rendering
├── levels.py                # Level lookup helpers
├── menu.py                  # All menu/HUD screens
├── graphics_algorithms.py   # The 7 required CG algorithms
├── constants.py             # All tunable constants / level configs
└── README.md
```

## 5. The 7 Computer Graphics Algorithms

All seven live in `graphics_algorithms.py`, are implemented manually
(no `pygame.draw.circle/line/polygon` used for their geometry), and are
genuinely called during normal gameplay:

| # | Algorithm | Function | Where it's used |
|---|---|---|---|
| 1 | **DDA Line Drawing** | `dda_line()` | Ghost "vision ray" drawn from a chasing ghost to Pac-Man (`ghost.py: draw_vision_ray`) |
| 2 | **Bresenham's Line Drawing** | `bresenham_line()` | Every maze wall segment is rendered by connecting neighboring wall-tile centers (`maze.py: _build_wall_surface`); also the HUD divider line (`game.py: _draw_hud`) and menu title underline (`menu.py: _draw_title`) |
| 3 | **Midpoint Circle** | `midpoint_circle()` | Pellets, power pellets (`maze.py: draw`), the lives indicator dots and the pulsing "vulnerability ring" around scared ghosts (`ghost.py: draw`) |
| 4 | **Midpoint Ellipse** | `midpoint_ellipse()` | Ghost eyes — sclera + pupil (`ghost.py: _draw_eyes`) |
| 5 | **Flood Fill** | `flood_fill()` | Generates the tinted floor texture by flood-filling outward from the player's spawn tile on a tiny offscreen surface, which also proves the generated maze is fully connected (`maze.py: _build_floor_texture`) |
| 6 | **Cohen–Sutherland Line Clipping** | `cohen_sutherland_clip()` | Clips the ghost vision-ray line to the play-area viewport before it is drawn (`ghost.py: draw_vision_ray`) |
| 7 | **Scan-Line Polygon Fill** | `scanline_polygon_fill()` | Fills Pac-Man's body/mouth-wedge polygon (`player.py: draw`) and the ghost body polygon — dome + wavy skirt (`ghost.py: draw`) |

## 6. Level Design

Rather than three hand-drawn mazes, each level's maze is **procedurally
generated** with a randomized depth-first-search ("recursive
backtracker"), which mathematically guarantees every tile is reachable
(no soft-locks), and then a controlled fraction of walls are knocked
down afterward to introduce loops. This single mechanism is what
differentiates the three levels (see `constants.LEVEL_CONFIG`):

| Level | Grid | Loop density | Feel | Ghost speed |
|---|---|---|---|---|
| 1 — Easy | 8×7 cells | 35% | open, many loops, easy to escape ghosts | 1.0× |
| 2 — Medium | 9×9 cells | 18% | more dead ends, tighter corridors | 1.3× |
| 3 — Hard | 10×10 cells | 6% | near-pure maze, long corridors, few loops | 1.6× |

Each level uses a fixed random seed, so the same layout appears every
time you play that level, while still being generated (not hand-authored).

## 7. Ghost AI

All four ghosts share the same grid-movement code (`ghost.py: update`)
but differ in how they pick a target tile:

- **Chaser (red):** targets Pac-Man's current tile directly.
- **Ambusher (pink):** targets a point 4 tiles ahead of Pac-Man in his
  current facing direction, trying to cut him off.
- **Random (cyan):** ignores Pac-Man and picks a uniformly random open
  direction at every intersection.
- **Patrol (orange):** switches between "chase Pac-Man" and "wander
  randomly" every 4 seconds.

At every intersection, a ghost scores each open (non-reversing)
direction by the squared distance from the resulting tile to its
target tile and picks the minimum (or the maximum, to flee, while
scared). When a ghost is eaten during power mode it becomes a pair of
eyes and returns to its home tile before resuming its normal behavior.

## 8. Suggestions for the Viva

- Open `graphics_algorithms.py` first and walk through each of the 7
  functions — they are self-contained and heavily commented.
- Run the game and pause it (`P`) to point out, on a static frame:
  the maze walls (Bresenham), pellets (midpoint circle), ghost eyes
  (midpoint ellipse), ghost body (scan-line fill).
- Collect a power pellet on screen to show the vulnerability ring
  (midpoint circle) and the ghosts turning blue.
- Stand still near a ghost so its vision ray is visible, to show the
  DDA line + Cohen–Sutherland clipping working together.
- Mention the flood-fill floor texture is regenerated per level from
  `maze.py: _build_floor_texture` — you can even temporarily break the
  maze generator to show unreachable tiles turning red, then fix it,
  as a live demonstration of what flood fill is actually verifying.
- Show `constants.LEVEL_CONFIG` to demonstrate that all difficulty
  tuning is centralized in one dictionary.
