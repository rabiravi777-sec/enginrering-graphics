"""
main.py
-------
Entry point for MAZE CHASE.

Run with:
    pip install pygame
    python main.py
"""

from game import Game


def main():
    game = Game()
    game.run()


if __name__ == "__main__":
    main()
