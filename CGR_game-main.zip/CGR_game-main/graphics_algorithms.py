"""
graphics_algorithms.py
-----------------------
This module contains the SEVEN Computer Graphics algorithms required for
the academic demonstration. Every function here is implemented manually
(no calls to pygame.draw.circle / pygame.draw.line / pygame.draw.polygon
for the actual geometry generation) and each one is genuinely used
elsewhere in the game (see maze.py, player.py, ghost.py).

Index of algorithms in this file:
    1. dda_line                 - DDA Line Drawing
    2. bresenham_line           - Bresenham's Line Drawing
    3. midpoint_circle          - Midpoint Circle Algorithm
    4. midpoint_ellipse         - Midpoint Ellipse Algorithm
    5. flood_fill               - Flood Fill Algorithm
    6. cohen_sutherland_clip    - Cohen-Sutherland Line Clipping
    7. scanline_polygon_fill    - Scan-Line Polygon Fill Algorithm
"""

import pygame


def _put_pixel(surface, x, y, color, thickness=1):
    """Helper: plot a single 'pixel' as a small square so lines are
    visible at normal window resolution. This is only a plotting
    helper - the actual point generation is done by the algorithms."""
    if thickness <= 1:
        surface.set_at((int(x), int(y)), color)
    else:
        half = thickness // 2
        rect = pygame.Rect(int(x) - half, int(y) - half, thickness, thickness)
        surface.fill(color, rect)


# --------------------------------------------------------------------------
# ALGORITHM 1: DDA LINE DRAWING
# --------------------------------------------------------------------------
def dda_line(surface, x1, y1, x2, y2, color, thickness=1):
    """
    Digital Differential Analyzer line drawing algorithm.
    Steps along the line using equal increments in x and y computed
    from the number of steps, which is the defining trait of DDA
    (as opposed to Bresenham's purely-integer error accumulation).
    """
    x1, y1, x2, y2 = float(x1), float(y1), float(x2), float(y2)
    dx = x2 - x1
    dy = y2 - y1
    steps = int(max(abs(dx), abs(dy)))
    if steps == 0:
        _put_pixel(surface, x1, y1, color, thickness)
        return

    x_inc = dx / steps
    y_inc = dy / steps

    x, y = x1, y1
    for _ in range(steps + 1):
        _put_pixel(surface, round(x), round(y), color, thickness)
        x += x_inc
        y += y_inc


# --------------------------------------------------------------------------
# ALGORITHM 2: BRESENHAM'S LINE DRAWING
# --------------------------------------------------------------------------
def bresenham_line(surface, x1, y1, x2, y2, color, thickness=1):
    """
    Bresenham's line algorithm using only integer arithmetic and an
    accumulating error term to decide when to step in the minor axis.
    Used throughout maze.py to render every wall segment in the game.
    """
    x1, y1, x2, y2 = int(round(x1)), int(round(y1)), int(round(x2)), int(round(y2))

    dx = abs(x2 - x1)
    dy = abs(y2 - y1)
    sx = 1 if x1 < x2 else -1
    sy = 1 if y1 < y2 else -1
    err = dx - dy

    x, y = x1, y1
    while True:
        _put_pixel(surface, x, y, color, thickness)
        if x == x2 and y == y2:
            break
        e2 = 2 * err
        if e2 > -dy:
            err -= dy
            x += sx
        if e2 < dx:
            err += dx
            y += sy


# --------------------------------------------------------------------------
# ALGORITHM 3: MIDPOINT CIRCLE ALGORITHM
# --------------------------------------------------------------------------
def midpoint_circle(surface, cx, cy, radius, color, filled=True):
    """
    Midpoint circle algorithm. Generates the boundary points of one
    octant and mirrors them across all 8 symmetric octants. When
    'filled' is true, a horizontal scan-line span is drawn between the
    mirrored x-coordinates on each row (fast filled-circle fill).
    Used to draw pellets, power pellets, and Pac-Man's body.
    """
    cx, cy, radius = int(round(cx)), int(round(cy)), int(round(radius))
    x = 0
    y = radius
    d = 1 - radius

    # Collect boundary points on the right half, one entry per scan-line,
    # so we know the left/right extent of the circle for filling.
    spans = {}

    def register(px, py):
        spans.setdefault(py, [px, px])
        span = spans[py]
        span[0] = min(span[0], px)
        span[1] = max(span[1], px)

    def plot_octants(x, y):
        register(cx + x, cy + y)
        register(cx - x, cy + y)
        register(cx + x, cy - y)
        register(cx - x, cy - y)
        register(cx + y, cy + x)
        register(cx - y, cy + x)
        register(cx + y, cy - x)
        register(cx - y, cy - x)

    plot_octants(x, y)
    while x < y:
        x += 1
        if d < 0:
            d += 2 * x + 1
        else:
            y -= 1
            d += 2 * (x - y) + 1
        plot_octants(x, y)

    if filled:
        for py, (x_min, x_max) in spans.items():
            pygame.draw.line(surface, color, (x_min, py), (x_max, py))
    else:
        for py, (x_min, x_max) in spans.items():
            _put_pixel(surface, x_min, py, color)
            _put_pixel(surface, x_max, py, color)


# --------------------------------------------------------------------------
# ALGORITHM 4: MIDPOINT ELLIPSE ALGORITHM
# --------------------------------------------------------------------------
def midpoint_ellipse(surface, cx, cy, rx, ry, color, filled=True):
    """
    Midpoint ellipse algorithm, processed in the two standard regions
    (region 1 where the curve slope is > -1, region 2 where it is < -1)
    each with its own decision parameter. Used to draw the ghosts' eyes.
    """
    cx, cy, rx, ry = int(round(cx)), int(round(cy)), int(round(rx)), int(round(ry))
    if rx <= 0 or ry <= 0:
        return

    spans = {}

    def register(px, py):
        spans.setdefault(py, [px, px])
        span = spans[py]
        span[0] = min(span[0], px)
        span[1] = max(span[1], px)

    def plot(x, y):
        register(cx + x, cy + y)
        register(cx - x, cy + y)
        register(cx + x, cy - y)
        register(cx - x, cy - y)

    rx2 = rx * rx
    ry2 = ry * ry

    # Region 1
    x, y = 0, ry
    d1 = ry2 - rx2 * ry + 0.25 * rx2
    dx = 2 * ry2 * x
    dy = 2 * rx2 * y
    plot(x, y)
    while dx < dy:
        x += 1
        dx += 2 * ry2
        if d1 < 0:
            d1 += dx + ry2
        else:
            y -= 1
            dy -= 2 * rx2
            d1 += dx - dy + ry2
        plot(x, y)

    # Region 2
    d2 = (ry2 * (x + 0.5) ** 2) + (rx2 * (y - 1) ** 2) - rx2 * ry2
    while y > 0:
        y -= 1
        dy -= 2 * rx2
        if d2 > 0:
            d2 += rx2 - dy
        else:
            x += 1
            dx += 2 * ry2
            d2 += dx - dy + rx2
        plot(x, y)

    if filled:
        for py, (x_min, x_max) in spans.items():
            pygame.draw.line(surface, color, (x_min, py), (x_max, py))
    else:
        for py, (x_min, x_max) in spans.items():
            _put_pixel(surface, x_min, py, color)
            _put_pixel(surface, x_max, py, color)


# --------------------------------------------------------------------------
# ALGORITHM 5: FLOOD FILL
# --------------------------------------------------------------------------
def flood_fill(surface, x, y, target_color, replacement_color):
    """
    Classic stack-based (iterative, to avoid recursion-limit issues)
    flood fill. Operates directly on a pygame Surface's pixels.

    Used in maze.py to generate the tinted floor texture: a tiny
    offscreen surface encodes the maze (walls vs open corridor) and we
    flood-fill outward from the player's spawn tile to discover every
    reachable floor tile (this simultaneously proves that the
    procedurally generated maze is fully connected).
    """
    target_color = tuple(target_color)
    replacement_color = tuple(replacement_color)
    if target_color == replacement_color:
        return

    width, height = surface.get_size()
    if not (0 <= x < width and 0 <= y < height):
        return

    start_color = tuple(surface.get_at((x, y)))[:3]
    if start_color != target_color:
        return

    stack = [(x, y)]
    visited = set()
    while stack:
        px, py = stack.pop()
        if (px, py) in visited:
            continue
        if not (0 <= px < width and 0 <= py < height):
            continue
        if tuple(surface.get_at((px, py)))[:3] != target_color:
            continue

        surface.set_at((px, py), replacement_color)
        visited.add((px, py))

        stack.append((px + 1, py))
        stack.append((px - 1, py))
        stack.append((px, py + 1))
        stack.append((px, py - 1))


# --------------------------------------------------------------------------
# ALGORITHM 6: COHEN-SUTHERLAND LINE CLIPPING
# --------------------------------------------------------------------------
_INSIDE = 0  # 0000
_LEFT = 1    # 0001
_RIGHT = 2   # 0010
_BOTTOM = 4  # 0100
_TOP = 8     # 1000


def _compute_out_code(x, y, xmin, ymin, xmax, ymax):
    code = _INSIDE
    if x < xmin:
        code |= _LEFT
    elif x > xmax:
        code |= _RIGHT
    if y < ymin:
        code |= _TOP
    elif y > ymax:
        code |= _BOTTOM
    return code


def cohen_sutherland_clip(x1, y1, x2, y2, xmin, ymin, xmax, ymax):
    """
    Cohen-Sutherland line clipping algorithm. Clips the segment
    (x1,y1)-(x2,y2) against the rectangular viewport
    [xmin,xmax] x [ymin,ymax]. Returns the clipped segment as
    (cx1, cy1, cx2, cy2), or None if the segment lies entirely
    outside the viewport.

    Used to clip ghost "vision ray" lines (drawn with DDA/Bresenham)
    to the visible play area before they are rendered.
    """
    out1 = _compute_out_code(x1, y1, xmin, ymin, xmax, ymax)
    out2 = _compute_out_code(x2, y2, xmin, ymin, xmax, ymax)

    while True:
        if not (out1 | out2):
            return (x1, y1, x2, y2)
        if out1 & out2:
            return None

        out_code = out1 if out1 else out2

        if out_code & _TOP:
            x = x1 + (x2 - x1) * (ymin - y1) / (y2 - y1)
            y = ymin
        elif out_code & _BOTTOM:
            x = x1 + (x2 - x1) * (ymax - y1) / (y2 - y1)
            y = ymax
        elif out_code & _RIGHT:
            y = y1 + (y2 - y1) * (xmax - x1) / (x2 - x1)
            x = xmax
        elif out_code & _LEFT:
            y = y1 + (y2 - y1) * (xmin - x1) / (x2 - x1)
            x = xmin

        if out_code == out1:
            x1, y1 = x, y
            out1 = _compute_out_code(x1, y1, xmin, ymin, xmax, ymax)
        else:
            x2, y2 = x, y
            out2 = _compute_out_code(x2, y2, xmin, ymin, xmax, ymax)


# --------------------------------------------------------------------------
# ALGORITHM 7: SCAN-LINE POLYGON FILL
# --------------------------------------------------------------------------
def scanline_polygon_fill(surface, polygon, color):
    """
    Scan-line polygon fill algorithm using an active edge list. For
    every horizontal scan-line, we find every polygon edge it crosses,
    compute the x-intersection, sort the intersections, and fill the
    spans between pairs of intersections.

    Used to render ghost bodies (dome + wavy skirt) and to cut Pac-Man's
    mouth wedge out of his already-drawn circular body.
    """
    if len(polygon) < 3:
        return

    ys = [p[1] for p in polygon]
    y_min = int(min(ys))
    y_max = int(max(ys))

    n = len(polygon)

    for y in range(y_min, y_max + 1):
        scan_y = y + 0.5  # sample at pixel center to avoid vertex ambiguity
        x_intersections = []

        for i in range(n):
            x1, y1 = polygon[i]
            x2, y2 = polygon[(i + 1) % n]

            if y1 == y2:
                continue  # skip horizontal edges

            if (scan_y >= min(y1, y2)) and (scan_y < max(y1, y2)):
                t = (scan_y - y1) / (y2 - y1)
                x = x1 + t * (x2 - x1)
                x_intersections.append(x)

        x_intersections.sort()

        for i in range(0, len(x_intersections) - 1, 2):
            x_start = int(round(x_intersections[i]))
            x_end = int(round(x_intersections[i + 1]))
            if x_end >= x_start:
                pygame.draw.line(surface, color, (x_start, y), (x_end, y))
