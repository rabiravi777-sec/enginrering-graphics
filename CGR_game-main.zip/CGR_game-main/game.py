"""
game.py
-------
The Game class owns the finite state machine and is the only place
with a "while running" loop. Each state has a matching
handle_event/update/draw trio so no nested loops are needed anywhere
else in the project.
"""

import sys
import math
import pygame

import constants as C
import graphics_algorithms as ga
import levels as L
import menu as MENU
from maze import Maze
from player import Player
from ghost import Ghost, GHOST_DEFS, STATE_SCARED, STATE_EATEN


class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("MAZE CHASE")
        self.screen = pygame.display.set_mode((C.SCREEN_WIDTH, C.SCREEN_HEIGHT))
        self.clock = pygame.time.Clock()

        self.fonts = {
            "huge": pygame.font.SysFont("arial", 54, bold=True),
            "large": pygame.font.SysFont("arial", 38, bold=True),
            "medium": pygame.font.SysFont("arial", 28, bold=True),
            "small": pygame.font.SysFont("arial", 18),
        }

        self.state = C.STATE_MAIN_MENU
        self.running = True

        self.main_menu_index = 0
        self.level_select_index = 0
        self.pause_index = 0
        self.game_over_index = 0
        self.victory_index = 0

        self.unlocked_levels = {1}
        self.current_level = 1

        self.score = 0
        self.lives = C.STARTING_LIVES

        self.maze = None
        self.player = None
        self.ghosts = []
        self.power_timer = 0.0
        self.power_active = False
        self.respawn_timer = 0.0
        self.respawning = False

        self._patrol_dt_holder = {"dt": 0.0}

    # ==================================================================
    # LEVEL SETUP
    # ==================================================================
    def load_level(self, level_number):
        self.current_level = level_number
        cfg = L.get_level_config(level_number)
        self.maze = Maze(level_number)
        self.player = Player(self.maze)

        self.ghosts = []
        for i, (behavior, color) in enumerate(GHOST_DEFS):
            home = self.maze.ghost_spawns[i % len(self.maze.ghost_spawns)]
            self.ghosts.append(
                Ghost(self.maze, behavior, color, home, cfg["ghost_speed"], rng_seed=1000 + i)
            )

        self.power_timer = 0.0
        self.power_active = False
        self.respawning = False
        self.respawn_timer = 0.0

    def start_new_game(self):
        self.score = 0
        self.lives = C.STARTING_LIVES
        self.load_level(1)
        self.state = C.STATE_PLAYING

    def restart_current_level_full_reset(self):
        self.score = 0
        self.lives = C.STARTING_LIVES
        self.load_level(self.current_level if self.current_level else 1)
        self.state = C.STATE_PLAYING

    # ==================================================================
    # MAIN LOOP
    # ==================================================================
    def run(self):
        while self.running:
            dt = self.clock.tick(C.FPS) / 1000.0
            dt = min(dt, 0.05)  # clamp huge spikes (e.g. window drag)
            self._patrol_dt_holder["dt"] = dt

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.KEYDOWN:
                    self.handle_key(event.key)

            self.update(dt)
            self.draw()
            pygame.display.flip()

        pygame.quit()
        sys.exit(0)

    # ==================================================================
    # INPUT
    # ==================================================================
    def handle_key(self, key):
        if self.state == C.STATE_MAIN_MENU:
            self._menu_nav(key, "main_menu_index", 3, self._activate_main_menu)
        elif self.state == C.STATE_LEVEL_SELECT:
            self._menu_nav(key, "level_select_index", len(L.LEVEL_ORDER) + 1,
                            self._activate_level_select, allow_escape=True)
        elif self.state == C.STATE_PLAYING:
            self._playing_key(key)
        elif self.state == C.STATE_PAUSED:
            self._menu_nav(key, "pause_index", 2, self._activate_pause)
            if key == pygame.K_p:
                self.state = C.STATE_PLAYING
        elif self.state == C.STATE_LEVEL_COMPLETE:
            if key in (pygame.K_RETURN, pygame.K_SPACE):
                self._advance_after_level_complete()
        elif self.state == C.STATE_GAME_OVER:
            self._menu_nav(key, "game_over_index", 3, self._activate_game_over)
        elif self.state == C.STATE_VICTORY:
            self._menu_nav(key, "victory_index", 3, self._activate_victory)

    def _menu_nav(self, key, attr, count, activate_fn, allow_escape=False):
        idx = getattr(self, attr)
        if key in (pygame.K_UP, pygame.K_w):
            idx = (idx - 1) % count
        elif key in (pygame.K_DOWN, pygame.K_s):
            idx = (idx + 1) % count
        elif key in (pygame.K_RETURN, pygame.K_SPACE):
            activate_fn(idx)
        elif key == pygame.K_ESCAPE and allow_escape:
            self.state = C.STATE_MAIN_MENU
        setattr(self, attr, idx)

    def _playing_key(self, key):
        if key in (pygame.K_UP, pygame.K_w):
            self.player.set_desired_direction(C.UP)
        elif key in (pygame.K_DOWN, pygame.K_s):
            self.player.set_desired_direction(C.DOWN)
        elif key in (pygame.K_LEFT, pygame.K_a):
            self.player.set_desired_direction(C.LEFT)
        elif key in (pygame.K_RIGHT, pygame.K_d):
            self.player.set_desired_direction(C.RIGHT)
        elif key == pygame.K_p:
            self.pause_index = 0
            self.state = C.STATE_PAUSED
        elif key == pygame.K_ESCAPE:
            self.state = C.STATE_MAIN_MENU

    def _activate_main_menu(self, idx):
        if idx == 0:
            self.start_new_game()
        elif idx == 1:
            self.level_select_index = 0
            self.state = C.STATE_LEVEL_SELECT
        elif idx == 2:
            self.running = False

    def _activate_level_select(self, idx):
        if idx == len(L.LEVEL_ORDER):
            self.state = C.STATE_MAIN_MENU
            return
        level_number = L.LEVEL_ORDER[idx]
        if level_number in self.unlocked_levels:
            self.score = 0
            self.lives = C.STARTING_LIVES
            self.load_level(level_number)
            self.state = C.STATE_PLAYING

    def _activate_pause(self, idx):
        if idx == 0:
            self.state = C.STATE_PLAYING
        elif idx == 1:
            self.state = C.STATE_MAIN_MENU

    def _activate_game_over(self, idx):
        if idx == 0:
            self.restart_current_level_full_reset()
        elif idx == 1:
            self.state = C.STATE_MAIN_MENU
        elif idx == 2:
            self.running = False

    def _activate_victory(self, idx):
        if idx == 0:
            self.start_new_game()
        elif idx == 1:
            self.state = C.STATE_MAIN_MENU
        elif idx == 2:
            self.running = False

    def _advance_after_level_complete(self):
        nxt = L.next_level(self.current_level)
        if nxt is None:
            self.state = C.STATE_VICTORY
            self.victory_index = 0
        else:
            self.unlocked_levels.add(nxt)
            self.load_level(nxt)
            self.state = C.STATE_PLAYING

    # ==================================================================
    # UPDATE
    # ==================================================================
    def update(self, dt):
        if self.state != C.STATE_PLAYING:
            return

        if self.respawning:
            self.respawn_timer -= dt
            if self.respawn_timer <= 0:
                self.respawning = False
            return

        collected = self.player.update(dt)
        if collected == "pellet":
            self.score += C.PELLET_SCORE
        elif collected == "power":
            self.score += C.POWER_PELLET_SCORE
            self.power_active = True
            self.power_timer = C.POWER_DURATION
            for g in self.ghosts:
                g.set_scared()

        if self.power_active:
            self.power_timer -= dt
            if self.power_timer <= 0:
                self.power_active = False
                for g in self.ghosts:
                    g.clear_scared()

        for g in self.ghosts:
            g.update(dt, self.player, self._patrol_dt_holder)

        self._check_ghost_collisions()

        if self.maze.remaining_pellets() == 0:
            self.state = C.STATE_LEVEL_COMPLETE

    def _check_ghost_collisions(self):
        px, py = self.player.x, self.player.y
        catch_dist = C.TILE_SIZE * 0.6
        for g in self.ghosts:
            gx, gy = g.rect_center()
            dist = math.hypot(px - gx, py - gy)
            if dist < catch_dist:
                if g.state == STATE_SCARED:
                    g.get_eaten()
                    self.score += C.GHOST_EAT_SCORE
                elif g.state == STATE_EATEN:
                    continue
                else:
                    self._player_caught()
                    break

    def _player_caught(self):
        self.lives -= 1
        for g in self.ghosts:
            g.reset_to_home()
        self.player.reset_to_spawn()
        self.power_active = False
        self.power_timer = 0.0
        if self.lives <= 0:
            self.state = C.STATE_GAME_OVER
            self.game_over_index = 0
        else:
            self.respawning = True
            self.respawn_timer = 1.0

    # ==================================================================
    # DRAW
    # ==================================================================
    def draw(self):
        if self.state == C.STATE_MAIN_MENU:
            MENU.draw_main_menu(self.screen, self.fonts, self.main_menu_index)
        elif self.state == C.STATE_LEVEL_SELECT:
            MENU.draw_level_select(self.screen, self.fonts, self.level_select_index,
                                    self.unlocked_levels)
        elif self.state in (C.STATE_PLAYING, C.STATE_PAUSED):
            self._draw_gameplay()
            if self.state == C.STATE_PAUSED:
                MENU.draw_pause(self.screen, self.fonts, self.pause_index)
        elif self.state == C.STATE_LEVEL_COMPLETE:
            self._draw_gameplay()
            MENU.draw_level_complete(self.screen, self.fonts, self.score, self.current_level)
        elif self.state == C.STATE_GAME_OVER:
            MENU.draw_game_over(self.screen, self.fonts, self.game_over_index, self.score)
        elif self.state == C.STATE_VICTORY:
            MENU.draw_victory(self.screen, self.fonts, self.victory_index, self.score)

    def _draw_gameplay(self):
        self.screen.fill(C.BLACK)
        self.maze.draw(self.screen)

        viewport = pygame.Rect(
            self.maze.offset_x, self.maze.offset_y,
            self.maze.cols * C.TILE_SIZE, self.maze.rows * C.TILE_SIZE,
        )
        for g in self.ghosts:
            g.draw_vision_ray(self.screen, self.player, viewport)

        for g in self.ghosts:
            g.draw(self.screen, scared_time_left=self.power_timer)

        self.player.draw(self.screen)

        self._draw_hud()

        if self.respawning:
            overlay = self.fonts["medium"].render("READY!", True, C.YELLOW)
            self.screen.blit(overlay, overlay.get_rect(
                center=(C.SCREEN_WIDTH // 2, C.SCREEN_HEIGHT // 2)))

    def _draw_hud(self):
        pygame.draw.rect(self.screen, (14, 14, 22), (0, 0, C.SCREEN_WIDTH, C.HUD_HEIGHT))
        ga.bresenham_line(self.screen, 0, C.HUD_HEIGHT - 1, C.SCREEN_WIDTH, C.HUD_HEIGHT - 1,
                           C.WALL_GLOW, thickness=2)

        score_label = self.fonts["medium"].render(f"SCORE: {self.score}", True, C.TEXT_COLOR)
        self.screen.blit(score_label, (16, 18))

        level_label = self.fonts["small"].render(
            L.level_display_name(self.current_level), True, C.TEXT_COLOR)
        self.screen.blit(level_label, level_label.get_rect(
            center=(C.SCREEN_WIDTH // 2, 34)))

        # lives shown as small midpoint-circle "pac-dots"
        for i in range(self.lives):
            cx = C.SCREEN_WIDTH - 30 - i * 30
            cy = 34
            ga.midpoint_circle(self.screen, cx, cy, 9, C.YELLOW)

        if self.power_active:
            power_label = self.fonts["small"].render(
                f"POWER: {self.power_timer:0.1f}s", True, C.POWER_COLOR)
            self.screen.blit(power_label, (16, 44))
